$(document).ready(function() {
    $("#departing").datepicker();
    $("#returning").datepicker();
    $("button").click(function() {
    	var selected = $("#dropdown option:selected").text();
        var departing = $("#departing").val();
        var returning = $("#returning").val();
        if (departing === "" || returning === "") {
			alert("Please select departing and returning dates.");
        } else {
			var abc=confirm("Would you like to go to " + selected + " on " + departing + " and return on " + returning + "?");
			if(abc==true)
			{
				alert("Journey is confirmed.. Happy Journey!!!");
			}
			if(abc==false)
			{
				alert("Journey is cancelled!!");
			}
        }
	
    });
});
